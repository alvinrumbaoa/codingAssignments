$(document).ready(function () {

    $('img').click(function () {
        $(this).hide();
    });
    $("#btn").click(function () {
        $('.box-img').show();
    });


});